package cp120a.evanspc.hw3;

public class Shape {
    public double area ()
    {
	//area is zero in this class
        return 0;     

    }

}
