package cp120a.evanspc.hw3;

public class ShapeTest {
	Shape s1 = new Circle (2.5);
	Shape s2 = new Rectangle (5.0, 4.0);
	Shape s3 = new Square (3.0, 3.0);
	Shape s4 = new Line (2.0, 3.0, 12.0, 13.0);
	Shape s5 = new Point (1.0, 2.0);
//	Shape s6 = new Triangle (1.0, 1.0, 1,0, 5.0, 3.0, 3.0;);

	System.out.println ("Circle with diameter of 2.5 produces area " + s1.area());
	System.out.println ("Rectangle with sides of 5.0 and 4.0 produces area " + s2.area());
	// compiler complains when I call .perimeter
	//System.out.println ("Rectangle with sides of 5.0 and 4.0 produces perimeter " + s2.perimeter());
	System.out.println ("Square with side of 3.0 produces area " + s3.area());
	// compiler complains when I call .perimeter
	//        System.out.println (s3.perimeter());
	System.out.println ("Line with points 2,3 and 12,13 has length" + s4.area());
	//System.out.println ("Point at 1.0, 2.0 is at " + s5.area());
	//System.out.println ("Triangle of  1.0, 1.0, 1,0, 5.0, 3.0, 3.0" + s5.area());
}

}
