package cp120a.evanspc.hw3;

public class Triangle {
// wasn't able to get to this, sorry
	//intended to implement via three sets of points, checking that they weren't in a line
}
